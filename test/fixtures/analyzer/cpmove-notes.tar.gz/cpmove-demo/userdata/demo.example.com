---
documentroot: /home/demo/public_html
homedir: /home/demo
phpversion: ea-php84
serveralias: www.demo.example.com
servername: demo.example.com
user: demo
