<?php
define( 'DB_NAME', 'demo_wp' );
define( 'DB_USER', 'demo_wp' );
define( 'DB_PASSWORD', 'Fixture-Password-123' );
define( 'DB_HOST', 'localhost' );
define( 'DB_CHARSET', 'utf8mb4' );
define( 'DB_COLLATE', '' );
define( 'AUTH_KEY', 'fixture-auth-key-value' );
define( 'WP_HOME', 'https://demo.example.com' );
$table_prefix = 'wp_';
require_once ABSPATH . 'wp-settings.php';
