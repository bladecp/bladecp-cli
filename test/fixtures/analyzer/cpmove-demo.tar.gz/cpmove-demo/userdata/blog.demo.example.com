---
documentroot: /home/demo/public_html/blog
homedir: /home/demo
phpversion: ea-php82
serveralias: www.blog.demo.example.com
servername: blog.demo.example.com
user: demo
