---
documentroot: /home/demo/loja.example.net
homedir: /home/demo
phpversion: ea-php81
serveralias: www.loja.demo.example.com
servername: loja.demo.example.com
user: demo
