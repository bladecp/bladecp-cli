-- MariaDB dump 10.19  Distrib 10.11.10-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: demo_wp
-- ------------------------------------------------------
-- Server version	10.11.10-MariaDB

/*!40101 SET NAMES utf8mb4 */;

DROP TABLE IF EXISTS `wp_options`;
CREATE TABLE `wp_options` (`option_id` bigint(20), `option_value` longtext);
INSERT INTO `wp_options` VALUES (1,'siteurl https://demo.example.com; INSERT INTO `wp_blogs` VALUES (9)'),(2,'it''s fine');
